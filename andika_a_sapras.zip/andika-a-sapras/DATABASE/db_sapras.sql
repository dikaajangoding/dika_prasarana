CREATE DATABASE IF NOT EXISTS db_sapras CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci;
USE db_sapras;
DROP TABLE IF EXISTS aspirasi;
DROP TABLE IF EXISTS siswa;
CREATE TABLE siswa(
 nis INT NOT NULL PRIMARY KEY,
 nama VARCHAR(100) NOT NULL,
 kelas VARCHAR(30) NOT NULL,
 email VARCHAR(100) NOT NULL,
 password VARCHAR(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
CREATE TABLE aspirasi(
 id_aspirasi INT NOT NULL AUTO_INCREMENT PRIMARY KEY,
 nis INT NOT NULL,
 judul_laporan VARCHAR(150) NOT NULL,
 keterangan TEXT NOT NULL,
 lokasi ENUM('kelas','toilet','mushola','lapangan','koridor','lab') NOT NULL,
 kategori_prioritas ENUM('rendah','sedang','tinggi') NOT NULL DEFAULT 'sedang',
 status ENUM('menunggu','diproses','selesai') NOT NULL DEFAULT 'menunggu',
 tanggal_dikirim TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
 CONSTRAINT fk_aspirasi_siswa FOREIGN KEY(nis) REFERENCES siswa(nis) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
INSERT INTO siswa VALUES
(2024001,'Budi Santoso','XII RPL 2','budi@sekolah.sch.id','$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi'),
(2024002,'Siti Aminah','XII RPL 2','siti@sekolah.sch.id','$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi');
INSERT INTO aspirasi(nis,judul_laporan,keterangan,lokasi,kategori_prioritas,status) VALUES
(2024001,'Kursi kelas rusak','Ada beberapa kursi yang rusak dan perlu diperbaiki.','kelas','sedang','menunggu'),
(2024002,'Lampu toilet mati','Lampu toilet tidak menyala.','toilet','tinggi','diproses');
