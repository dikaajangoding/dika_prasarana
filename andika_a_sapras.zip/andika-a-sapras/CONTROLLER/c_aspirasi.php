<?php
require_once __DIR__.'/../MODEL/m_aspirasi.php';
$m=new ModelAspirasi(); $aksi=$_POST['aksi']??$_GET['aksi']??'';
if($aksi==='tambah'){
 $ok=$m->add($_POST['nis'],trim($_POST['judul']),trim($_POST['keterangan']),$_POST['lokasi'],$_POST['prioritas'],$_POST['status']);
 header("Location: ../VIEW/v_aspirasi.php?msg=".urlencode($ok?'Aspirasi berhasil ditambahkan':'Gagal menambah aspirasi'));exit;
}
if($aksi==='edit'){
 $ok=$m->update($_POST['id'],$_POST['nis'],trim($_POST['judul']),trim($_POST['keterangan']),$_POST['lokasi'],$_POST['prioritas'],$_POST['status']);
 header("Location: ../VIEW/v_aspirasi.php?msg=".urlencode($ok?'Aspirasi berhasil diubah':'Gagal mengubah aspirasi'));exit;
}
if($aksi==='hapus'){
 $ok=$m->delete($_GET['id']??0);
 header("Location: ../VIEW/v_aspirasi.php?msg=".urlencode($ok?'Aspirasi berhasil dihapus':'Gagal menghapus aspirasi'));exit;
}
header("Location: ../VIEW/v_aspirasi.php");