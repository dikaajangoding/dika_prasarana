<?php
require_once __DIR__.'/../MODEL/m_siswa.php';
$m=new ModelSiswa(); $aksi=$_POST['aksi']??$_GET['aksi']??'';
if($aksi==='tambah'){
 $ok=$m->add($_POST['nis'],trim($_POST['nama']),trim($_POST['kelas']),trim($_POST['email']),$_POST['password']);
 header("Location: ../VIEW/v_siswa.php?msg=".urlencode($ok?'Siswa berhasil ditambahkan':'Gagal menambah siswa'));exit;
}
if($aksi==='edit'){
 $ok=$m->update($_POST['nis'],trim($_POST['nama']),trim($_POST['kelas']),trim($_POST['email']),$_POST['password']??'');
 header("Location: ../VIEW/v_siswa.php?msg=".urlencode($ok?'Siswa berhasil diubah':'Gagal mengubah siswa'));exit;
}
if($aksi==='hapus'){
 $ok=$m->delete($_GET['nis']??0);
 header("Location: ../VIEW/v_siswa.php?msg=".urlencode($ok?'Siswa berhasil dihapus':'Gagal menghapus siswa'));exit;
}
header("Location: ../VIEW/v_siswa.php");