<?php
require_once __DIR__.'/MODEL/m_siswa.php'; require_once __DIR__.'/MODEL/m_aspirasi.php';
$s=new ModelSiswa();$a=new ModelAspirasi();
?>
<!doctype html><html lang="id"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Andika A Sapras</title><link rel="stylesheet" href="ASSETS/css/a_style.css"></head><body>
<?php include __DIR__.'/VIEW/v_nav.php'; ?>
<div class="container"><div class="top"><div><h1>Dashboard Andika A Sapras</h1><p class="muted">Versi 50% — fokus CRUD data utama.</p></div></div>
<div class="grid"><div class="card">Data Siswa<div class="stat"><?= $s->count() ?></div><p class="muted">Tambah, lihat, ubah, hapus.</p><a class="btn btn-primary" href="VIEW/v_siswa.php">Kelola Siswa</a></div>
<div class="card">Data Aspirasi<div class="stat"><?= $a->count() ?></div><p class="muted">Tambah, lihat, ubah, hapus.</p><a class="btn btn-primary" href="VIEW/v_aspirasi.php">Kelola Aspirasi</a></div>
<div class="card"><b>Fitur yang belum dibuat</b><p class="muted">Login, histori, progres, umpan balik, upload foto, dan filter lanjutan.</p></div></div>
<div class="card"><h3>Alur sederhana</h3><p>Admin mengelola <b>Siswa</b> dan <b>Aspirasi</b> menggunakan operasi CRUD: Create, Read, Update, Delete.</p></div>
</div></body></html>