<?php
class Koneksi {
    private $host="localhost", $username="root", $password="", $db="db_sapras";
    public $koneksi;
    public function __construct(){
        $this->koneksi=mysqli_connect($this->host,$this->username,$this->password,$this->db);
        if(!$this->koneksi) die("Koneksi database gagal: ".mysqli_connect_error());
        mysqli_set_charset($this->koneksi,"utf8mb4");
    }
}