<?php
require_once __DIR__.'/m_koneksi.php';
class ModelAspirasi{
 private $db;
 function __construct(){ $this->db=(new Koneksi())->koneksi; }
 function all($q=''){
  $q=mysqli_real_escape_string($this->db,$q);
  $where=$q?"WHERE a.judul_laporan LIKE '%$q%' OR s.nama LIKE '%$q%' OR a.lokasi LIKE '%$q%'":'';
  $r=mysqli_query($this->db,"SELECT a.*,s.nama nama_siswa,s.kelas FROM aspirasi a JOIN siswa s ON a.nis=s.nis $where ORDER BY a.id_aspirasi DESC");
  $d=[];while($x=mysqli_fetch_assoc($r))$d[]=$x;return $d;
 }
 function get($id){$id=(int)$id;$r=mysqli_query($this->db,"SELECT * FROM aspirasi WHERE id_aspirasi=$id");return $r?mysqli_fetch_assoc($r):null;}
 function add($nis,$judul,$ket,$lokasi,$prioritas,$status){
  $nis=(int)$nis;$judul=mysqli_real_escape_string($this->db,$judul);$ket=mysqli_real_escape_string($this->db,$ket);$lokasi=mysqli_real_escape_string($this->db,$lokasi);$prioritas=mysqli_real_escape_string($this->db,$prioritas);$status=mysqli_real_escape_string($this->db,$status);
  return mysqli_query($this->db,"INSERT INTO aspirasi(nis,judul_laporan,keterangan,lokasi,kategori_prioritas,status) VALUES($nis,'$judul','$ket','$lokasi','$prioritas','$status')");
 }
 function update($id,$nis,$judul,$ket,$lokasi,$prioritas,$status){
  $id=(int)$id;$nis=(int)$nis;$judul=mysqli_real_escape_string($this->db,$judul);$ket=mysqli_real_escape_string($this->db,$ket);$lokasi=mysqli_real_escape_string($this->db,$lokasi);$prioritas=mysqli_real_escape_string($this->db,$prioritas);$status=mysqli_real_escape_string($this->db,$status);
  return mysqli_query($this->db,"UPDATE aspirasi SET nis=$nis,judul_laporan='$judul',keterangan='$ket',lokasi='$lokasi',kategori_prioritas='$prioritas',status='$status' WHERE id_aspirasi=$id");
 }
 function delete($id){$id=(int)$id;return mysqli_query($this->db,"DELETE FROM aspirasi WHERE id_aspirasi=$id");}
 function count(){return mysqli_fetch_assoc(mysqli_query($this->db,"SELECT COUNT(*) n FROM aspirasi"))['n'];}
}