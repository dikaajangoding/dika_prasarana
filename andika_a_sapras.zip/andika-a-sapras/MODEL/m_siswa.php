<?php
require_once __DIR__.'/m_koneksi.php';
class ModelSiswa{
 private $db;
 function __construct(){ $this->db=(new Koneksi())->koneksi; }
 function all($q=''){
  $q=mysqli_real_escape_string($this->db,$q);
  $where=$q?"WHERE nama LIKE '%$q%' OR kelas LIKE '%$q%' OR nis LIKE '%$q%'":'';
  $r=mysqli_query($this->db,"SELECT nis,nama,kelas,email FROM siswa $where ORDER BY nama");
  $d=[]; while($x=mysqli_fetch_assoc($r))$d[]=$x; return $d;
 }
 function get($nis){$nis=(int)$nis;$r=mysqli_query($this->db,"SELECT * FROM siswa WHERE nis=$nis");return $r?mysqli_fetch_assoc($r):null;}
 function add($nis,$nama,$kelas,$email,$password){
  $nis=(int)$nis;$nama=mysqli_real_escape_string($this->db,$nama);$kelas=mysqli_real_escape_string($this->db,$kelas);$email=mysqli_real_escape_string($this->db,$email);$hash=password_hash($password,PASSWORD_BCRYPT);
  return mysqli_query($this->db,"INSERT INTO siswa(nis,nama,kelas,email,password) VALUES($nis,'$nama','$kelas','$email','$hash')");
 }
 function update($nis,$nama,$kelas,$email,$password=''){
  $nis=(int)$nis;$nama=mysqli_real_escape_string($this->db,$nama);$kelas=mysqli_real_escape_string($this->db,$kelas);$email=mysqli_real_escape_string($this->db,$email);
  $sql="UPDATE siswa SET nama='$nama',kelas='$kelas',email='$email'";
  if($password!=='')$sql.=",password='".mysqli_real_escape_string($this->db,password_hash($password,PASSWORD_BCRYPT))."'";
  return mysqli_query($this->db,$sql." WHERE nis=$nis");
 }
 function delete($nis){$nis=(int)$nis;return mysqli_query($this->db,"DELETE FROM siswa WHERE nis=$nis");}
 function count(){return mysqli_fetch_assoc(mysqli_query($this->db,"SELECT COUNT(*) n FROM siswa"))['n'];}
}