<?php $page=$page??''; ?>
<div class="nav"><div class="container">
<div class="brand">Andika A Sapras</div>
<div><a href="../index.php">Dashboard</a><a href="siswa.php">CRUD Siswa</a><a href="aspirasi.php">CRUD Aspirasi</a></div>
</div></div>