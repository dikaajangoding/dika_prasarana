<?php
require_once __DIR__.'/../MODEL/m_siswa.php';$m=new ModelSiswa();$q=$_GET['q']??'';$data=$m->all($q);$edit=$m->get($_GET['edit']??0);$msg=$_GET['msg']??'';
?>
<!doctype html><html lang="id"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>CRUD Siswa - Andika A Sapras</title><link rel="stylesheet" href="../ASSETS/css/a_style.css"></head><body>
<?php include __DIR__.'/_nav.php'; ?><div class="container"><div class="top"><div><h1>CRUD Siswa</h1><p class="muted">Kelola data siswa.</p></div><a class="btn btn-primary" href="siswa.php">+ Data Baru</a></div>
<?php if($msg):?><div class="alert"><?=htmlspecialchars($msg)?></div><?php endif;?>
<div class="card"><form method="get" class="actions"><input name="q" value="<?=htmlspecialchars($q)?>" placeholder="Cari nama, kelas, atau NIS" style="flex:1"><button class="btn btn-secondary">Cari</button></form></div><br>
<div class="card"><h3><?= $edit?'Edit Siswa':'Tambah Siswa' ?></h3><form action="../CONTROLLER/c_siswa.php" method="post"><input type="hidden" name="aksi" value="<?= $edit?'edit':'tambah' ?>">
<?php if($edit):?><input type="hidden" name="nis" value="<?=htmlspecialchars($edit['nis'])?>"><?php endif;?>
<div class="form-grid"><div class="form-group"><label>NIS</label><input name="nis" required value="<?=htmlspecialchars($edit['nis']??'')?>" <?= $edit?'readonly':'' ?>></div>
<div class="form-group"><label>Nama</label><input name="nama" required value="<?=htmlspecialchars($edit['nama']??'')?>"></div>
<div class="form-group"><label>Kelas</label><input name="kelas" required value="<?=htmlspecialchars($edit['kelas']??'')?>"></div>
<div class="form-group"><label>Email</label><input type="email" name="email" required value="<?=htmlspecialchars($edit['email']??'')?>"></div>
<div class="form-group"><label>Password <?= $edit?'(opsional)':'' ?></label><input type="password" name="password" <?= $edit?'':'required' ?>></div></div>
<div class="actions"><button class="btn btn-primary">Simpan</button><?php if($edit):?><a class="btn btn-outline" href="siswa.php">Batal</a><?php endif;?></div></form></div><br>
<div class="card table-wrap"><table><thead><tr><th>NIS</th><th>Nama</th><th>Kelas</th><th>Email</th><th>Aksi</th></tr></thead><tbody>
<?php foreach($data as $x):?><tr><td><?=htmlspecialchars($x['nis'])?></td><td><?=htmlspecialchars($x['nama'])?></td><td><?=htmlspecialchars($x['kelas'])?></td><td><?=htmlspecialchars($x['email'])?></td><td class="actions"><a class="btn btn-outline" href="?edit=<?=$x['nis']?>">Edit</a><a class="btn btn-danger" href="../CONTROLLER/c_siswa.php?aksi=hapus&nis=<?=$x['nis']?>" onclick="return confirm('Hapus data ini?')">Hapus</a></td></tr><?php endforeach;?></tbody></table></div></div></body></html>