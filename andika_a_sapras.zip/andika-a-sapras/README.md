# Andika A Sapras
Versi 50% dari aplikasi Pengaduan Sarana Sekolah.

## Fokus versi ini
Aplikasi sengaja dibuat sederhana dan hanya menyelesaikan CRUD data utama:
- CRUD Siswa
- CRUD Aspirasi

CRUD = Create (tambah), Read (lihat), Update (edit), Delete (hapus).

## Belum dikerjakan
Login/register, histori, progres perbaikan, umpan balik, upload foto, dashboard statistik lengkap, dan filter lanjutan.

## Instalasi
1. Copy folder `andika-a-sapras` ke `htdocs`.
2. Buka phpMyAdmin.
3. Import `DATABASE/d_db_sapras.sql`.
4. Pastikan MySQL XAMPP aktif.
5. Buka `http://localhost/andika-a-sapras/`.

## Database
Nama database: `db_sapras`
Koneksi default: localhost / root / password kosong.
